# IQ Test App

A simple Flutter app template for an IQ test.